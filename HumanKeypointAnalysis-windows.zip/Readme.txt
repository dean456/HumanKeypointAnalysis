1. Please download python windows installer with version > 3.8
2. Run "set-environment-variable.bat" as administrator 
3. Set PYTHONPATH to be the folder that you installed python
(for example: PYTHONPATH = C:\python-3.10.3)
4. Set Path to be the folder that you installed python
(for example: path = C:\python-3.10.3)
5. Go to the the folder that you installed python and run "prerequisit_install.bat"
6. Go to https://github.com/dean456/HumanKeypointAnalysis, download the zip file
7. Go to the folder that you extracted the zip file
8. Edit the main.py file, change the datapath to the folder that stores videos and the folders contain json folder analysed from the openpose
(for example: datapath = D:\\001_007)
9. Adjust the featureset as mentioned last time
10. Run "run_analysis.bat" and you will get a folder "images" that stores plots and a "report.txt" that displayed the classifer performance. 
